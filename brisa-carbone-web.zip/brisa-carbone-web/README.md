# Brisa Carbone — Sitio web

Landing page personal · Servicios de contenido estratégico y media buying.

---

## Cómo subir esto a GitHub y tener un link público (gratis)

### Paso 1 — Crear cuenta en GitHub
1. Andá a [github.com](https://github.com) y creá una cuenta si no tenés (gratis).
2. Iniciá sesión.

### Paso 2 — Crear un repositorio nuevo
1. Arriba a la derecha clickeá el `+` → **New repository**.
2. **Repository name**: poné tu nombre de usuario seguido de `.github.io`
   Ejemplo: si tu usuario es `brisacarbone`, el repo se llama `brisacarbone.github.io`
   *(Esto es importante: con ese nombre exacto, GitHub te da un dominio gratis sin configurar nada.)*
3. Dejalo en **Public**.
4. NO marques "Add a README file" (ya tenés uno).
5. Click en **Create repository**.

### Paso 3 — Subir los archivos
1. En la página del repo recién creado, vas a ver un link que dice **"uploading an existing file"**. Clickealo.
2. Arrastrá los dos archivos de esta carpeta (`index.html` y `README.md`).
3. Abajo, en "Commit changes", escribí algo corto como "primera versión".
4. Click en **Commit changes**.

### Paso 4 — Activar GitHub Pages
1. En el repo, andá a la pestaña **Settings** (arriba a la derecha).
2. En el menú izquierdo, clickeá **Pages**.
3. En "Build and deployment" → "Source", elegí **Deploy from a branch**.
4. En "Branch", elegí **main** y carpeta **/ (root)**. Click en **Save**.
5. Esperá 1–2 minutos. Refrescá la página.
6. Arriba vas a ver: **"Your site is live at https://[tuusuario].github.io/"**

Ese es el link que le mandás a BRILOG y a cualquier cliente.

---

## Editar el sitio después

Para cambiar texto, precios o agregar tu WhatsApp:
1. En GitHub entrá al archivo `index.html`.
2. Click en el ícono del lápiz (✏️) arriba a la derecha del archivo.
3. Editá lo que necesites.
4. Bajá hasta abajo y click en **Commit changes**.
5. Los cambios se ven en tu sitio en 1–2 minutos.

### Lugares que probablemente quieras editar:

- **WhatsApp** (línea con `[TU-WHATSAPP]`): reemplazalo por tu número con código de país sin `+`. Ejemplo: `5491127511968`. Si no querés WhatsApp, borrá la línea completa.
- **Precios o planes** (sección "Planes"): cualquier valor o servicio.
- **Email**: ya está como `carbonebrisa935@gmail.com`.

---

## ¿Querés un dominio propio?

Cuando estés lista (ej: `brisacarbone.com`), se puede conectar a este sitio. Comprás el dominio en [Namecheap](https://namecheap.com) o [Cloudflare](https://cloudflare.com) (~USD 10–15/año) y se configura desde Settings → Pages → Custom domain.
